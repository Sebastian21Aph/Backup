<!DOCTYPE html>
	<html lang="es">
	<head>
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="css/materialize.css">
		<!--mobile-->
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
		<script type="text/javascript" src="../jquery.js"></script>
		<script src="../js/materialize.js"></script>
		<title>Tienda Ropa</title>
	</head>
	<body>


	
<nav class=" teal darken-1">
  <ul class="right hide-on-med-and-down ">
    <li><a href="index.php">Inicio</a></li>
    <li><a href="ropa.php">Ropa</a></li>
    <li><a href="#!">Proveedor</a></li>
    <li><a href="#!">JOIN</a></li>
  </ul>
  <ul id="slide-out" class="side-nav">
    <li><a href="#!"></a></li>
    <li><a href="#!">Second Sidebar Link</a></li>
  </ul>
  <a href="#" data-activates="slide-out" class="button-collapse"><i class="mdi-navigation-menu"></i></a>
</nav>