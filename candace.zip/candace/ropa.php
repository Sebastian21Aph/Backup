<?php 
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
error_reporting(0);
include("includeQuery/conexion.php");
include ("plantillaIncludes/header.php");
include("includeQuery/insertarRopa.php")

 ?>

 	  <div class="container">


 


	  	
        <div class="row">
        	
        	<div class="col s12 center-align"><h1>Ropa</h1></div>
        </div>

	  	<div class="row">
	  		<div class="col s3">&nbsp</div>
	  		<div class="col s6">
	  			
            <form action="#" method="POST">
            	
          <input placeholder="Ingrese Nombre" id="nombre" name="nombre" type="text" class="validate" required>
         
          <label for="first_name">Nombre ropa</label> 



          <input type="date" name="fecha" step="1" min="2000-01-01" max="2015-12-31" value="2015-01-01"  class="validate" required>

          <label for="first_name">Fecha de Ingreso</label> 



          <input  type="number"  name="proveedor" placeholder="Ingrese id proveedor" id="proveedor"  min="0" class="validate" required>

          <label for="textarea1">Id proveedor</label>


         
          <br>

          <p>*Actualizacion y borrados Nombre</p>
        

          <input type="submit" name="boton"  id="registrar"   value="insertar" class="waves-effect waves-light btn " />


          <input type="submit" name="boton" id="registrar"   value="actualizar" class="waves-effect waves-light btn"/>


          <input type="submit" name="boton" id="registrar"   value="borrar" class="waves-effect waves-light btn"/>

          </form>
            


	  		</div>


	  	</div>
	  		



	  		<div class="row">

	  

	  	    <div class="col m12 center-align">
	  	    	
              <h1>GRID</h1>


            <iframe src="includeQuery/tablaProducto.php" width="100%" height="500px" frameborder="0">
              

            </iframe>




	  	    </div>
	  			




	  		</div>
	  	
	  </div> <!--fin contenedor-->
