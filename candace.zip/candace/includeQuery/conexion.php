<?php 


$db = new mysqli('localhost', 'u646610080_rodriguezsebas', 'Utd_2020', 'u646610080_rodriguezsebas');

if($db->connect_errno > 0){
	 echo "<script>alert('usuario y contraseña son incorrecto')</script>";  
     echo "<script>window.location='index.php';</script>";  
    die('Imposible conectar [' . $db->connect_error . ']');
}

else{
 
     
         
      // echo "<script>alert('entro');</script>"; 
}




 ?>