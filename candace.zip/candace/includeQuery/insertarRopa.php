<?php 


//error_reporting(E_ALL);
//ini_set('display_errors', '1');

error_reporting(0);
include("conexion.php");
$nombreRopa = $_POST['nombre'];
$fecha = $_POST['fecha'];;
$proveedor = $_POST['proveedor'];
$boton = $_POST['boton'];


switch ($boton) {
	case 'insertar':
		
		insertar($nombreRopa, $fecha, $proveedor,$boton );

    break;


    case 'actualizar':
	
        actualizar($nombreRopa, $fecha, $proveedor);
   
    break;



    case 'borrar':
	
        borrar($nombreRopa);	
   
    break;

        default:
		# code...
		break;
}



function insertar($nombreRopa, $fecha, $proveedor,$boton){
include("conexion.php");	

$sql = "INSERT INTO Ropa (id_ropa, Nombre, Fecha_ingreso , id_proveedor) VALUES(NULL, '$nombreRopa', '$fecha','$proveedor')";
 
if(! $db->query($sql)){
     die('Ocurrio un error ejecutando el query [' . $db->error . ']');
}
 
//echo 'Filas Insertadas:'.$db->affected_rows;

$db->close();

}



function actualizar($nombreRopa, $fecha, $proveedor){

	
include("conexion.php");

$sql = "UPDATE Ropa SET  Fecha_ingreso = '$fecha' , id_proveedor = $proveedor WHERE Nombre = '$nombreRopa'; ";
 

if(! $db->query($sql)){die('Ocurrio un error ejecutando el query [' . $db->error . ']');}
 
$usuarioExiste = $db->affected_rows;	


$usuarioExiste = $db->affected_rows;

if($usuarioExiste ==0)
{

echo "<script>alert('El registro $nombreRopa no existe')</script>";
$db->close();
   

}

$db->close();



}

function borrar($nombreRopa){
include("conexion.php");	

$sql = "DELETE FROM Ropa WHERE Nombre = '$nombreRopa'; ";
 

if(! $db->query($sql)){
     die('Ocurrio un error ejecutando el query [' . $db->error . ']');
}
 
 
//echo 'Filas borradas:'.$db->affected_rows;

$usuarioExiste = $db->affected_rows;

if($usuarioExiste ==0)
{

echo "<script>alert('El registro $nombreRopa no existe')</script>";
$db->close();
   

}
}




 ?>