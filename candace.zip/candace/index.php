<?php 

include ("plantillaIncludes/header.php");

 ?>


	  <div class="container">
	  	
        <div class="row">
        	
        	<div class="col s12 center-align"><h1>Ropa</h1></div>
        </div>

	  	<div class="row">
	  		<div class="col s2">&nbsp</div>
	  		<div class="col m8 center-align">

            
   <!--  <i class="material-icons">add</i>
-->
           <img class="hoverable responsive-img " src="img/inicio.jpg" alt="">

	  	</div>
	  		<div class="col s2">&nbsp</div>
	  	</div>
	  </div>


	

	  <div class="row">
	  	
	  	<div class="col s11 right-align">
	  		<footer>
	  			<small >Diseñado 2015</small>

	  		</footer>
	  		
	  	</div>
	  </div>




      

		<script type="text/javascript" src="js/jquery.js"></script>
		<script type="text/javascript" src="js/materialize.js"></script>
		

<script>
	$(".button-collapse").sideNav();
	
	$('.button-collapse').sideNav('hide');
// Hide sideNav
$('.button-collapse').sideNav('hide');
	  $('.button-collapse').sideNav({
      menuWidth: 300, // Default is 240
      edge: 'right', // Choose the horizontal origin
      closeOnClick: true // Closes side-nav on <a> clicks, useful for Angular/Meteor

    }
  );
</script>
	
	</body>
	</html>	